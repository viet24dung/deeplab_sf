# apt-get update
# apt-get install -y libsm6 libxext6 libxrender-dev
# pip install opencv-python --trusted-host=pypi.python.org --trusted-host=pypi.org --trusted-host=files.pythonhosted.org
import numpy as np
epochs = 200
lr_init = 1e-3
batch_size = 4
n_classes = 21
dataset =''
step_per_ep = 1

train_file = 'train_aug.txt' #'train.txt' #
folder_mask = 'MaskAug/' #'SegmentationClassMask/' # 
folder_image = 'JPEGImages/'
val_file = 'val.txt'

img_size = (513,513)

back_bone = 'mobilenetv2' #mobilenetv2, xception
better_model = False
multi_gpu = False
load_pretrain = False
is_data_agumentation = True
load_pretrain_imagenet = True
note = 'load_pretrain_imagenet'
print('note when training', epochs, batch_size, img_size, load_pretrain, better_model,back_bone,is_data_agumentation, note)

def lr_schedule(epoch):
    if epoch < 10:
        return 1e-5
    lr = lr_init
    lr = lr * np.power(1 - epoch / epochs, 0.9)
    print('lr =', lr)
    return lr

    lr = lr_init
    if epoch > 180:
        lr *= 1e-2
    elif epoch > 160:
        lr *= 5e-2
    elif epoch > 120:
        lr *= 1e-1
    elif epoch > 80:
        lr *= 5e-1
    
    print('Learning rate: ', lr)
    return lr

    lr = 2e-3
    if epoch > 190:
        lr = 3e-5
    elif epoch > 175:
        lr = 7e-5
    elif epoch > 160:
        lr = 1e-4
    elif epoch > 130:
        lr = 3e-4
    elif epoch > 100:
        lr = 7e-4
    elif epoch > 50:
        lr = 1e-3
    #lr = 0.007
    #lr = lr * np.power(1 - epoch / epochs, 0.9)
    print('lr =', lr)
    return lr

    
    lr = 1e-3
    if epoch > 180:
        lr *= 0.5e-3
    elif epoch > 160:
        lr *= 1e-3
    elif epoch > 120:
        lr *= 1e-2
    elif epoch > 80:
        lr *= 1e-1
    print('Learning rate: ', lr)
    return lr

# palette (color map) describes the (B, G, R): Label pair
palette = { (0, 0,   0) : 0 ,
            (0, 0, 128) : 1,
            (0, 128, 0) : 2,
            (0, 128, 128) : 3,
            (128, 0, 0) : 4,
            (128, 0, 128) : 5,
            (128, 128, 0) : 6,
            (128, 128, 128) : 7,
            (0, 0, 64) : 8,
            (0, 0, 192) : 9,
            (0, 128, 64) : 10,
            (0, 128, 192) : 11,
            (128, 0, 64) : 12,
            (128, 0, 192) : 13,
            (128, 128, 64) : 14,
            (128, 128, 192) : 15,
            (0, 64, 0) : 16,
            (0, 64, 128) : 17,
            (0, 192, 0) : 18,
            (0, 192, 128) : 19,
            (128, 64, 0) : 20,
            (192,224,224) : 255}
