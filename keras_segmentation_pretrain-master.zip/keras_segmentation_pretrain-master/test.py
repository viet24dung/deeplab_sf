print('check folder data')

import glob
import os

image_path_list = glob.glob(os.path.join('SegmentationClass', '*'))[:10]
print(image_path_list)
