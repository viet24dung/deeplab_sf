apt-get update
apt-get install -y libsm6 libxext6 libxrender-dev
pip install opencv-python --trusted-host=pypi.python.org --trusted-host=pypi.org --trusted-host=files.pythonhosted.org
python seg.py
